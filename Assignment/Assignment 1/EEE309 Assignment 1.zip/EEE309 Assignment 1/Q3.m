close all;
clear all;
clc;
tau_n = 1e-6; 
g0 = 1e21; 
t1 = 2*tau_n; 
t = linspace(0, 6*tau_n, 200); 
dt = t(2) - t(1);


dn = zeros(size(t));
for i = 1:length(t)-1
    g = (t(i) <= t1) * g0; % g0 when ON
    dn(i+1) = dn(i) + dt * (g - dn(i) / tau_n);
end


plot(t*1e6, dn, 'b-');
xlabel('Time ');
ylabel('\deltan(t) ');
grid on;
hold on;