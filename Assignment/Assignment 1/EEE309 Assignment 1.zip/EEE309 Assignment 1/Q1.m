close all;
clear all;
clc;
tau_p = 1e-6; 
dp0 = 1e15; 
t = linspace(0, 5*tau_p, 100); 
dt = t(2) - t(1);


dp_num = zeros(size(t));  % Numerical Euler Method
dp_num(1) = dp0;
for i = 1:length(t)-1
    dp_num(i+1) = dp_num(i) - dt * (dp_num(i) / tau_p);
end


dp_exact = dp0 * exp(-t / tau_p);    % Exact Solution


figure;
plot(t*1e6, dp_num, 'b-', t*1e6, dp_exact, 'r--');
xlabel('Time (\mus)');
ylabel('\deltap(t) (cm^{-3})');
title('Problem 1: Thermal Relaxation');
legend('Numerical (Euler)', 'Analytical');
hold on;
grid on;