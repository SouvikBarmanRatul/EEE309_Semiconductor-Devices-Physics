close all;
clear all;
clc;
tau_p = 1e-6; 
g = 1e21; 
t = linspace(0, 5*tau_p, 100); 
dt = t(2) - t(1);


dn = zeros(size(t));         % Euler Method
for i = 1:length(t)-1
    dn(i+1) = dn(i) + dt * (g-dn(i) / tau_p);
end


plot(t*1e6, dn, 'b-'); 
yline(g * tau_p, 'r--', 'Steady State');
xlabel('Time'); ylabel('\deltan(t) )');
legend('Numerical', 'Steady State Line');
grid on;
hold on;