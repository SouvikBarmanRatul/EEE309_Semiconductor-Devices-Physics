clear all;
close all;
clc;

Dp = 10;
tau = 1e-6;
Lp = sqrt(Dp*tau);

p0 = 1e15;

h = 0.01*Lp;
x_pos = 0:h:5*Lp;

dt = 0.4*h^2/Dp;
t = 0:dt:5*tau;

N = length(x_pos);
M = length(t);

% Initial condition
p_pos = zeros(M,N);

% Boundary conditions
p_pos(:,1) = p0;
p_pos(:,N) = p0*exp(-5);

% Euler Method
for n = 1:M-1

    for k = 2:N-1

        p_pos(n+1,k) = p_pos(n,k) ...
            + dt*(Dp*(p_pos(n,k+1)-2*p_pos(n,k)+p_pos(n,k-1))/h^2 ...
            - p_pos(n,k)/tau);

    end

end

% Negative side - symmetric
x_neg = -fliplr(x_pos(2:end));
p_neg = fliplr(p_pos(:,2:end));

% Combine both sides
x = [x_neg x_pos];
p = [p_neg p_pos];

% Steady-state solution from Problem 4
p_exact = p0*exp(-abs(x)/Lp);

% 2D surface plot
figure(1)
surf(x,t,p)
shading interp
grid on
xlabel('Length (x)')
ylabel('Time (s)')
zlabel('dp(x,t)')
title('2D surface/color plot of dp(x, t)')

% dp vs x at different times
figure(2)
hold on

plot(x,p(find(t>=0.5*tau,1),:))
plot(x,p(find(t>=tau,1),:))
plot(x,p(find(t>=2*tau,1),:))
plot(x,p(find(t>=5*tau,1),:))
plot(x,p_exact,'--')

grid on
xlabel('Length (x)')
ylabel('dp(x,t)')
legend('0.5\tau','\tau','2\tau','5\tau','Steady State')
title('Spatial Distribution')

% dp vs t at different positions
figure(3)
hold on

plot(t,p(:,find(x==0,1)))
plot(t,p(:,find(abs(x-Lp)==min(abs(x-Lp)),1)))
plot(t,p(:,find(abs(x-2*Lp)==min(abs(x-2*Lp)),1)))

grid on
xlabel('Time (s)')
ylabel('dp(x,t)')
title('Time Dependence')

