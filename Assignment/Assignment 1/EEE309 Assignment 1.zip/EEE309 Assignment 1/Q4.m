clear all;
close all;
clc;

Dp = 10;
tau = 1e-6;
Lp = sqrt(Dp*tau);

p0 = 1e15;

h = 0.01*Lp;

% Positive side
x_pos = 0:h:5*Lp;

p_pos = zeros(1,length(x_pos));
q_pos = zeros(1,length(x_pos));

p_pos(1) = p0;
q_pos(1) = -p0/Lp;

% Euler Method - Positive side
for k = 2:length(x_pos)

    p_pos(k) = p_pos(k-1) + h*q_pos(k-1);
    q_pos(k) = q_pos(k-1) + h*(p_pos(k-1)/(Dp*tau));

end

% Negative side - symmetric
x_neg = -fliplr(x_pos(2:end));

p_neg = fliplr(p_pos(2:end));
q_neg = -fliplr(q_pos(2:end));

% Combine negative and positive sides
x = [x_neg, x_pos];
p = [p_neg, p_pos];
q = [q_neg, q_pos];

% Analytical solution
p_exact = p0*exp(-abs(x)/Lp);


figure
plot(x,p)
grid on

xlabel('Length (x)')
ylabel('dp(x)')
title('Steady-State Spatial Distribution')