clc; 
clear;
close all;

% Parameters
Vth = -0.3489;             
Kn = 0.0015539;            

%% Plot 1: Output Characteristics (ID vs VDS)
Vds = 0:0.02:3;
overdrives = [0.5, 1.0, 1.5, 2.0];

figure(1); hold on;
for Vov = overdrives
    Id = zeros(size(Vds));
    for i = 1:length(Vds)
        if Vds(i) < Vov
            Id(i) = Kn * (Vov * Vds(i) - 0.5 * Vds(i)^2); % Linear
        else
            Id(i) = 0.5 * Kn * (Vov^2);                   % Saturation
        end
    end
    plot(Vds, Id * 1000, 'LineWidth', 1.5);
end

xlabel('V_{DS} (V)'); 
ylabel('I_D (mA)');
title('Task 2(b): Output Characteristics');
grid on;
hold off;

%% Plot 2: Transfer Characteristics (ID vs VGS)
Vgs = linspace(-0.5, 1.8, 200);
Vds_fix = 2.0;
Id_tr = zeros(size(Vgs));

for i = 1:length(Vgs)
    Vov = Vgs(i) - Vth;
    if Vov > 0
        if Vds_fix < Vov
            Id_tr(i) = Kn * (Vov * Vds_fix - 0.5 * Vds_fix^2);
        else
            Id_tr(i) = 0.5 * Kn * (Vov^2);
        end
    end
end

figure(2);
plot(Vgs, Id_tr * 1000, 'b', 'LineWidth', 1.5);
xlabel('V_{GS} (V)'); ylabel('I_D (mA)');
title('Task 2(b): Transfer Characteristic (V_{DS} = 2V)');
grid on;