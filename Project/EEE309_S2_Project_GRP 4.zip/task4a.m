%% Task 4(a)

clear;
clc;
close all;

VGS = [2.3 2.5 2.7 3.0 3.3 3.6 4.0 4.4 4.8 5.2 5.6 6.0];

ID = [0.0263 0.1060 0.2315 0.5388 0.9369 1.4294 2.3378 3.5122 4.8146 6.1602 8.1364 9.9614] * 1e-3;

sqrtID = sqrt(ID);

plot(VGS, sqrtID, 'o-');
xlabel('V(GS)');
ylabel('sqrt(I(D))');
grid on;

interp1(sqrtID, VGS, 0, 'linear', 'extrap')
