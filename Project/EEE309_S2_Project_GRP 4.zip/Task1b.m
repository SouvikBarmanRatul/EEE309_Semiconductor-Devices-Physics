clear;
close all;
clc;

% Task 1(b) Group 4

vg = -2:0.001:3;
q = 1.6e-19;
e0 = 8.854e-14;
es = 11.7*e0;
cox = 3.453e-7;
na = 4e14;
vfb = -0.9;
vth = -0.349;%from task 1a
xdmax = 1.305e-4;%also from task 1a

xd = zeros(size(vg));
a = sqrt(2*q*es*na)/cox;

for i = 1:length(vg)

    if vg(i) <= vfb
        xd(i) = 0;
    elseif vg(i) < vth
        v = vg(i) - vfb;
        y = (-a + sqrt(a^2 + 4*v))/2;
        ps = y^2;
        xd(i) = sqrt((2*es*ps)/(q*na));
    else
        xd(i) = xdmax;
    end

end

% Convert cm to um
xd = xd*1e4;

figure

plot(vg,xd,'LineWidth',1.5)
grid on
hold on
plot([vth vth],[0 xdmax*1e4],'--r')
xlabel('Gate Voltage (V)')
ylabel('Depletion Width (um)')

title('Depletion Width vs Gate Voltage')