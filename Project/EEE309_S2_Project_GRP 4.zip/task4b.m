%% Task 4(b)

clear;
clc;
close all;

VGS = [2.3 2.5 2.7 3.0 3.3 3.6 4.0 4.4 4.8 5.2 5.6 6.0];

ID = [0.0263 0.1060 0.2315 0.5388 0.9369 1.4294 2.3378 3.5122 4.8146 6.1602 8.1364 9.9614] * 1e-3;

sqrt_ID = sqrt(ID);
VTH = 2.1015;

Cox = (3.9 * 8.854e-14) / (10e-7);
W = 10e-4;
L = 1e-4;
mu_eff = 450;

simID = 0.5 * mu_eff * Cox * (W/L) .* max(VGS - VTH, 0).^2;

plot(VGS, ID*1000, 'o'); hold on;
plot(VGS, simID*1000, '-');
xlabel('V(GS)'); ylabel('ID');
title('Experimental vs Simulated ID-V(GS)');
legend('Experimental', 'Simulation');
grid on;